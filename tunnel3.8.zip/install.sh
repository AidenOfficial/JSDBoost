#!/bin/sh
chmod +x tunnel
cd v2core
chmod +x *
cd ..
echo "删除旧的 v2ray-core"
rm -rf /usr/local/v2core
echo "已支持开启启动"
echo "ulimit -n 655350" >> /etc/profile
echo "nohup /usr/local/v2core/v2core -config=/usr/local/v2core/tunnel.json > /dev/null 2>&1 &" >> /etc/profile
echo "放入 v2ray-core"
mv v2core /usr/local/
echo "写入更大文件操作符数目"
ulimit -n 655350
